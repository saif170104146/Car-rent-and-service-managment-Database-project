/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConnectMSSQL;

import java.awt.Component;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

/**
 *
 * @author daiya
 */
public class Renderer  extends DefaultListCellRenderer implements ListCellRenderer<Object>{

  public Component getListCellRendererComponent(JList<?> list,Object value,int index,boolean isSelected,boolean cellHasFocus){
  // return super.getListCellRendererComponent(list,value,index,isSelected,cellHasFocus);

   return null;
  }

}
    

